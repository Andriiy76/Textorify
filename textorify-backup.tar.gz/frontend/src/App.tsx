// frontend/src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Container, Typography, Box, Button } from '@mui/material';
import SignupPage from './pages/SignupPage';
import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import Header from './components/Header';
import Footer from './components/Footer';
import VerifyEmailPage from './pages/VerifyEmailPage'; //  Добавили импорт

function App() {
  return (
    <Router>
      <Header />
      <Container maxWidth="md">
        <Box sx={{ my: 4 }}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/verify-email/:token" element={<VerifyEmailPage />} /> {/* Добавили маршрут */}
            <Route
              path="*"
              element={
                <Typography variant="h6" align="center">
                  Page Not Found. <Link to="/">Go Home</Link>
                </Typography>
              }
            />
          </Routes>
        </Box>
      </Container>
      <Footer />
    </Router>
  );
}

export default App;