// frontend/src/pages/HomePage.tsx
import React from 'react';
import { Container, Typography } from '@mui/material';

const HomePage: React.FC = () => {
  return (
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" align="center" gutterBottom>
        Welcome to Textorify!
      </Typography>
      <Typography variant="body1" align="center">
        This is the home page.  More content will be added soon.
      </Typography>
    </Container>
  );
};

export default HomePage;