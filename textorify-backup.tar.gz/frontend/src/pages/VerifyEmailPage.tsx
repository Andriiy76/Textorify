// frontend/src/pages/VerifyEmailPage.tsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Typography, Alert, Box, CircularProgress } from '@mui/material';
import axios from 'axios';

const VerifyEmailPage: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const verifyEmail = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`/api/auth/verify-email?token=${token}`); //  Передаем токен как query parameter

        setMessage(response.data.message);
        setError(null);
        setTimeout(() => {
          navigate('/login');
        }, 3000); // Redirect after 3 seconds

      } catch (error: any) {
        setError(error.response?.data?.message || 'Email verification failed.');
        setMessage(null);
      } finally {
        setLoading(false);
      }
    };

    if (token) {
      verifyEmail();
    }
  }, [token, navigate]);

  return (
    <Container maxWidth="sm">
      <Box sx={{ mt: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Verify Email
        </Typography>
        {loading && <CircularProgress />}
        {error && <Alert severity="error">{error}</Alert>}
        {message && <Alert severity="success">{message}</Alert>}
      </Box>
    </Container>
  );
};

export default VerifyEmailPage;