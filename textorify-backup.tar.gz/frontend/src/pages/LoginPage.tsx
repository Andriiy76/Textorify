// frontend/src/pages/LoginPage.tsx
import React from 'react';
import LoginForm from '../components/LoginForm'; //  Правильный путь
import { Container, Typography } from '@mui/material';

const LoginPage: React.FC = () => {
  return (
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" align="center" gutterBottom>
        Login
      </Typography>
      <LoginForm />
    </Container>
  );
};

export default LoginPage;