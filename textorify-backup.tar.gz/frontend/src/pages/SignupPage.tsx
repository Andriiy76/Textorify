// frontend/src/pages/SignupPage.tsx
import React from 'react';
import SignupForm from '../components/SignupForm'; //  Правильный путь
import { Container, Typography } from '@mui/material';

const SignupPage: React.FC = () => {
  return (
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" align="center" gutterBottom>
        Sign Up
      </Typography>
      <SignupForm />
    </Container>
  );
};

export default SignupPage;