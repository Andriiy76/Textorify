// frontend/src/components/SignupForm.tsx
import React, { useState } from 'react';
import { TextField, Button, Box, Alert, CircularProgress } from '@mui/material';
import { useForm, SubmitHandler } from 'react-hook-form';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

interface SignupFormValues {
  email: string;
  password: string;
  confirmPassword: string;
}

const SignupForm: React.FC = () => {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<SignupFormValues>();
  const [error, setError] = React.useState<string | null>(null);
  const [success, setSuccess] = React.useState<string | null>(null); //  Изменили тип
  const navigate = useNavigate();

  const onSubmit: SubmitHandler<SignupFormValues> = async (data) => {
    setError(null);
    setSuccess(null); //  Сбрасываем сообщение об успехе

    if (data.password !== data.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    try {
      const response = await axios.post(
        '/api/auth/signup',
        data,
        { withCredentials: true }
      );

      if (response.status === 201) {
        setSuccess(response.data.message); //  Сохраняем сообщение об успехе из ответа
      } else {
        setError(response.data.message || 'Signup failed.');
      }
    } catch (error: any) {
      setError(error.response?.data?.message || 'An error occurred during signup.');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ mt: 1 }}>
      {error && <Alert severity="error">{error}</Alert>}
      {success && <Alert severity="success">{success}</Alert>} {/*  Отображаем сообщение об успехе */}
      <TextField
        margin="normal"
        required
        fullWidth
        id="email"
        label="Email Address"
        {...register('email', {
          required: 'Email is required',
          pattern: {
            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
            message: 'Invalid email address',
          },
        })}
        error={!!errors.email}
        helperText={errors.email?.message}
        autoComplete="email"
        autoFocus
        disabled={isSubmitting}
      />
      <TextField
        margin="normal"
        required
        fullWidth
        label="Password"
        type="password"
        id="password"
        {...register('password', {
          required: 'Password is required',
          minLength: {
            value: 8,
            message: 'Password must be at least 8 characters long',
          },
        })}
        error={!!errors.password}
        helperText={errors.password?.message}
        autoComplete="new-password"
        disabled={isSubmitting}
      />
      <TextField
        margin="normal"
        required
        fullWidth
        label="Confirm Password"
        type="password"
        id="confirmPassword"
        {...register('confirmPassword', {
          required: 'Confirm Password is required',
          validate: (value, formValues) => {
            if (value !== formValues.password) {
              return 'Passwords do not match';
            }
            return true;
          },
        })}
        error={!!errors.confirmPassword}
        helperText={errors.confirmPassword?.message}
        autoComplete="new-password"
        disabled={isSubmitting}
      />
      <Button
        type="submit"
        fullWidth
        variant="contained"
        sx={{ mt: 3, mb: 2 }}
        disabled={isSubmitting}
      >
        {isSubmitting ? <CircularProgress size={24} color="inherit" /> : 'Sign Up'}
      </Button>
    </Box>
  );
};

export default SignupForm;