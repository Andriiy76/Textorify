// frontend/src/components/LoginForm.tsx
import React from 'react';
import { TextField, Button, Box, Alert, CircularProgress } from '@mui/material';
import { useForm, SubmitHandler } from 'react-hook-form';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

interface LoginFormValues { //  Типы полей формы
  email: string;
  password: string;
}

const LoginForm: React.FC = () => {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginFormValues>(); //  Используем useForm
  const [error, setError] = React.useState<string | null>(null); //  Состояние для ошибки
  const navigate = useNavigate();

  const onSubmit: SubmitHandler<LoginFormValues> = async (data) => {
    setError(null); //  Сбрасываем ошибку
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/auth/login`,
        data,
        { withCredentials: true } //  Чтобы отправлять cookie
      );

      if (response.status === 201 || response.status === 200) { //  Успешный вход
        //  Редирект на главную страницу (или другую защищенную страницу)
        navigate('/');
      } else {
        //  Обработка ошибок (если сервер вернул не 200/201)
        setError(response.data.message || 'Login failed'); //  Показываем сообщение об ошибке
      }
    } catch (error: any) {
      //  Обработка ошибок (сетевые ошибки, ошибки 401, 403 и т.д.)
      setError(error.response?.data?.message || 'An error occurred during login.');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ mt: 1 }}>
      {error && <Alert severity="error">{error}</Alert>} {/*  Показываем ошибку, если она есть */}
      <TextField
        margin="normal"
        required
        fullWidth
        id="email"
        label="Email Address"
        {...register('email', {
          required: 'Email is required',
          pattern: { //  Простая валидация email
            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
            message: 'Invalid email address',
          },
        })}
        error={!!errors.email}
        helperText={errors.email?.message}
        autoComplete="email"
        autoFocus
        disabled={isSubmitting} //  Блокируем поля, пока идет отправка
      />
      <TextField
        margin="normal"
        required
        fullWidth
        label="Password"
        type="password"
        id="password"
        {...register('password', {
          required: 'Password is required',
          minLength: {
            value: 8,
            message: 'Password must be at least 8 characters long',
          },
        })}
        error={!!errors.password}
        helperText={errors.password?.message}
        autoComplete="current-password"
        disabled={isSubmitting} //  Блокируем поля, пока идет отправка
      />
      <Button
        type="submit"
        fullWidth
        variant="contained"
        sx={{ mt: 3, mb: 2 }}
        disabled={isSubmitting} //  Блокируем кнопку, пока идет отправка
      >
        {isSubmitting ? <CircularProgress size={24} color="inherit" /> : 'Sign In'} {/*  Индикатор загрузки */}
      </Button>
    </Box>
  );
};

export default LoginForm;