// frontend/.eslintrc.js
module.exports = {
    // ... другие настройки ESLint ...
    extends: [
      // ... другие правила ...
      'plugin:react/recommended', //  Добавляем
      'plugin:react/jsx-runtime', //  Добавляем
    ],
    rules: {
      // ... другие правила ...
      // "react/jsx-uses-react": "off", //  Уже не нужно, если есть 'plugin:react/jsx-runtime'
      // "react/react-in-jsx-scope": "off", // Уже не нужно, если есть 'plugin:react/jsx-runtime'
    },
    settings: { //  Добавляем
      react: {
        version: 'detect', //  Автоматически определяем версию React
      },
    },
    parser: '@typescript-eslint/parser', //  Указываем парсер TypeScript
  };