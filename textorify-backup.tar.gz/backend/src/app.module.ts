// backend/src/app.module.ts
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { RemultService } from './remult/remult.service';
import { User } from './auth/entities/user.entity'; //  Правильный путь!
import { Session } from './auth/entities/session.entity'; // Правильный путь
import { TypeOrmModule } from '@nestjs/typeorm'; // Добавлен

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      url: process.env.DATABASE_URL,
      autoLoadEntities: true, //  Важно!
      synchronize: true, //  Важно! (но ОСТОРОЖНО в production)
      entities: [User, Session],
    }),
    AuthModule,
  ],
  controllers: [],
  providers: [
    RemultService,
  ],
})
export class AppModule {}