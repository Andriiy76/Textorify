// backend/src/remult/remult.service.ts
import { Injectable, Scope, Inject, Optional } from '@nestjs/common';
import { createPostgresDataProvider } from "remult/postgres";
import { Remult, SqlDatabase } from 'remult';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { Product } from '../shared/entities';
import { User } from '../auth/entities/user.entity';
import { Session } from '../auth/entities/session.entity';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class RemultService {
    static remult: Remult;
    constructor(private configService: ConfigService) {
       RemultService.remult = new Remult();
    }
    async getRemult() {
        if (!RemultService.remult.dataProvider) {
           RemultService.remult.dataProvider = await createPostgresDataProvider({ // используем await
                connectionString: this.configService.get<string>('DATABASE_URL')
           });
       }
       return RemultService.remult;
    }
}