// backend/src/remult/remult.interceptor.ts
import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { RemultService } from './remult.service';
@Injectable()
export class RemultInterceptor implements NestInterceptor {
  constructor(private readonly remultService: RemultService) {}

  async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
    const req = context.switchToHttp().getRequest();
      const remult = await this.remultService.getRemult();
      req.remult = remult;
    return next.handle();
  }
}