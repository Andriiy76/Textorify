// backend/src/auth/auth.controller.ts
import { Controller, Post, Body, Res, Get, Req, UseGuards, Inject, Query, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { SignupDto } from './dto/signup.dto';
import { LoginDto } from './dto/login.dto';
import { Response, Request } from 'express';
import { Public } from './decorators/public.decorator';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { User } from './entities/user.entity';
import { Remult } from 'remult';
import { Session } from './entities/session.entity';
import { JwtPayload } from './interfaces/jwt-payload.interface';
import { RemultService } from '../remult/remult.service';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
const ms = require('ms');

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly remultService: RemultService,
  ) { }

  @Post('signup')
  @Public()
  async signup(@Body() signupDto: SignupDto, @Res({ passthrough: true }) response: Response, @Req() req: Request) {
    try {
      const remult = await this.remultService.getRemult();
      const { user, accessToken, refreshToken } = await this.authService.signup(signupDto);

      const jwtExpiresIn = process.env.JWT_EXPIRES_IN || '1h';
      const expiresInMilliseconds = ms(jwtExpiresIn);

      if (isNaN(expiresInMilliseconds)) {
        throw new UnauthorizedException(`Invalid JWT_EXPIRES_IN value: ${jwtExpiresIn}`);
      }

      const expiryDate = new Date(Date.now() + expiresInMilliseconds);

      response.cookie('jwt', accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'none',
        domain: process.env.COOKIE_DOMAIN,
        expires: expiryDate,
      });

      return { refreshToken, user: remult.repo(User).toJson(user), message: 'Registration successful! Please check your email to verify your account.' }; // Добавлено сообщение
    } catch (error) {
      console.error("Signup failed", error);
      throw error;
    }
  }

  @Post('login')
  @Public()
  async login(@Body() loginDto: LoginDto, @Res({ passthrough: true }) response: Response, @Req() req: Request) {
    try {
      const remult = await this.remultService.getRemult();
      const { user, accessToken, refreshToken } = await this.authService.login(loginDto);

      const jwtExpiresIn = process.env.JWT_EXPIRES_IN || '1h';
      const expiresInMilliseconds = ms(jwtExpiresIn);

      if (isNaN(expiresInMilliseconds)) {
        throw new UnauthorizedException(`Invalid JWT_EXPIRES_IN value: ${jwtExpiresIn}`);
      }

      const expiryDate = new Date(Date.now() + expiresInMilliseconds);

      response.cookie('jwt', accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'none',
        domain: process.env.COOKIE_DOMAIN,
        expires: expiryDate,
      });

      return { refreshToken, user: remult.repo(User).toJson(user) };
    } catch (error) {
      console.error("Login failed", error);
      throw error;
    }
  }

  @UseGuards(JwtAuthGuard)
  @Post('logout')
  async logout(@Res({ passthrough: true }) response: Response, @Req() req: Request) {
    try {
      response.clearCookie('jwt', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'none',
        domain: process.env.COOKIE_DOMAIN,
      });
      const remult = await this.remultService.getRemult();
      if (req['user']?.sessionId) {
        const sessionRepo = remult.repo(Session);
        const session = await sessionRepo.findId(req['user'].sessionId);
        if (session) {
          session.isActive = false;
          await sessionRepo.save(session);
        }
      }
      return { message: 'Logged out successfully' };
    } catch (error) {
      console.error("Logout failed", error);
      throw error;
    }
  }

  @Post('refresh')
  async refresh(@Body() refreshTokenDto: RefreshTokenDto, @Res({ passthrough: true }) response: Response, @Req() req: Request) {
    try {
      const remult = await this.remultService.getRemult();
      const { accessToken, refreshToken: newRefreshToken } = await this.authService.refresh(refreshTokenDto.refreshToken, remult);

      const jwtExpiresIn = process.env.JWT_EXPIRES_IN || '1h';
      const expiresInMilliseconds = ms(jwtExpiresIn);

      if (isNaN(expiresInMilliseconds)) {
        throw new UnauthorizedException(`Invalid JWT_EXPIRES_IN value: ${jwtExpiresIn}`);
      }

      const expiryDate = new Date(Date.now() + expiresInMilliseconds);

      response.cookie('jwt', accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'none',
        domain: process.env.COOKIE_DOMAIN,
        expires: expiryDate,
      });

      return { refreshToken: newRefreshToken };
    } catch (error) {
      console.error("Refresh token failed", error);
      throw error;
    }
  }

  @Get('verify-email')
  @Public()
  async verifyEmail(@Query('token') token: string, @Res() res: Response) {
    try {
      await this.authService.verifyEmail(token);
      res.status(200).json({ message: 'Email verified successfully! You can now log in.' }); // JSON response on success
    } catch (error) {
      console.error("Email verification failed", error);
      res.status(400).json({ message: error.message || 'Email verification failed.' }); // JSON response on failure
    }
  }
}