// backend/src/auth/entities/user.entity.ts
import { Entity, Fields, Validators, Relations } from 'remult';

@Entity('users', { //  Правильное имя таблицы!
  allowApiCrud: true,
})
export class User {
    @Fields.autoIncrement()
    id!: number;

    @Fields.string({
      validate: [Validators.required, Validators.email],
    })
    email!: string;

    @Fields.string()
    password!: string;

    @Fields.boolean()
    isEmailVerified = false;

    @Fields.string({ includeInApi: false }) //  Не отправляем токен в API
    emailVerificationToken?: string;

    @Fields.date({ includeInApi: false })
    emailVerificationTokenExpiresAt?: Date;

    @Fields.string({ includeInApi: false })
    resetPasswordToken?: string;

    @Fields.date({ includeInApi: false })
    resetPasswordTokenExpiresAt?: Date;

    @Fields.integer()
    planId = 1;
}