// backend/src/auth/entities/session.entity.ts
import { Entity, Fields, Relations } from 'remult';
import { User } from './user.entity';

@Entity('sessions', {
  allowApiCrud: false, //  Сессии не должны быть доступны через API напрямую
})
export class Session {
  @Fields.uuid()
  id!: string;

  @Relations.toOne(() => User) //  Связь с пользователем
  user!: User;

  @Fields.number()
  userId:number

  @Fields.string({ includeInApi: false })
  refreshToken!: string;

  @Fields.date()
  expiresAt!: Date;

  @Fields.boolean()
  isActive = true;

    @Fields.createdAt()
    createdAt?: Date;

    @Fields.updatedAt()
    lastActivityAt?: Date

  @Fields.string({ includeInApi: false })
  ipAddress?: string;

  @Fields.string({ includeInApi: false })
  userAgent?: string;
}