// backend/src/auth/utils/sendEmail.ts
export const sendVerificationEmail = async (email: string, token: string) => {
  console.log('Sending verification email to:', email, 'with token:', token);
  //  TODO:  Реализовать отправку email (с помощью Nodemailer)
};