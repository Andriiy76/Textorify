// backend/src/auth/auth.service.ts
import { Injectable, UnauthorizedException, Inject, HttpException, HttpStatus } from '@nestjs/common'; //  Добавили HttpException
import { User } from './entities/user.entity';
import { Session } from './entities/session.entity';
import * as bcrypt from 'bcryptjs';
import { JwtService } from '@nestjs/jwt';
import { SignupDto } from './dto/signup.dto';
import { LoginDto } from './dto/login.dto';
import { sendVerificationEmail } from './utils/sendEmail';
import { Remult, Repository } from 'remult';
import { ConfigService } from '@nestjs/config';
import { randomUUID } from 'crypto';
import { RemultService } from '../remult/remult.service';
import { InjectRepository } from '@nestjs/typeorm'; //  Добавляем!
import { DataSource } from 'typeorm'; // Добавляем!

@Injectable()
export class AuthService {
  private userRepo: Repository<User>;
  constructor(
    private jwtService: JwtService,
    private configService: ConfigService,
    private readonly remultService: RemultService,
    private dataSource: DataSource,
  ) {}
async onModuleInit() {
    const remult = await this.remultService.getRemult();
    this.userRepo = remult.repo(User);
  }
  async signup(signupDto: SignupDto): Promise<{ user: User; accessToken: string; refreshToken: string; }> {
      const { email, password, confirmPassword } = signupDto;

      // if (password !== confirmPassword) {
      //   throw new UnauthorizedException('Passwords do not match');
      // }
      const userRepo =  this.dataSource.getRepository(User);
      const existingUser = await userRepo.findOne({ where: { email: email } });
      console.log("existingUser:", existingUser); //  Добавляем console.log

      throw new Error('TEST'); //  Временно!

      // const hashedPassword = await bcrypt.hash(password, 10);

      // const user = userRepo.create({
      //   email,
      //   password: hashedPassword,
      //   emailVerificationToken: randomUUID(),
      //   emailVerificationTokenExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      // });
      // await userRepo.save(user);

      // if (user.emailVerificationToken) {
      //   await sendVerificationEmail(user.email, user.emailVerificationToken);
      // }

      // return this.createSession(user);
    }

  async login(loginDto: LoginDto): Promise<{ user: User; accessToken: string; refreshToken: string; }> {
    const { email, password } = loginDto;
    const userRepo =  this.dataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { email: email } });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      throw new UnauthorizedException('Invalid credentials');
    }

    if (!user.isEmailVerified) {
      throw new UnauthorizedException('Email not verified');
    }

    return this.createSession(user);
  }

  private async createSession(user: User): Promise<{ user: User; accessToken: string; refreshToken: string; }> {
     const remult = await this.remultService.getRemult(); // добавили remult
    const sessionRepo = remult.repo(Session);
    const session = sessionRepo.create({
      user,
      userId: user.id,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      refreshToken: randomUUID(),
    });
    await sessionRepo.save(session);

    const payload = {
      id: user.id,
      email: user.email,
      planId: user.planId,
      session_id: session.id,
    };
    const accessToken = this.jwtService.sign(payload);

    return { user, accessToken, refreshToken: session.refreshToken };
  }

  async refresh(refreshToken: string, remult: Remult) {
    const sessionRepo = remult.repo(Session);
    const session = await sessionRepo.findOne({ where: { refreshToken, isActive: true } });
    if (!session) {
      throw new UnauthorizedException('Invalid refresh token');
    }

    if (session.expiresAt < new Date()) {
      throw new UnauthorizedException('Refresh token expired');
    }

    return await this.createSession(session.user)
  }

      async verifyEmail(token: string): Promise<string> {
          const userRepo =  this.dataSource.getRepository(User);
        const user = await userRepo.findOne({ where: { emailVerificationToken: token } });

        if (!user) {
          throw new HttpException('Invalid verification token', HttpStatus.BAD_REQUEST);
        }

        if (user.emailVerificationTokenExpiresAt < new Date()) {
          throw new HttpException('Verification token expired', HttpStatus.BAD_REQUEST);
        }

        user.isEmailVerified = true;
        user.emailVerificationToken = null;
        user.emailVerificationTokenExpiresAt = null;
        await userRepo.save(user);

        return 'Email successfully verified!';
      }
}