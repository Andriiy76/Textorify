// backend/src/auth/dto/reset-password.dto.ts
//  Поля: token, password, confirmPassword