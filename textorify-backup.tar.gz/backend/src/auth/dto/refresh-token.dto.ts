// backend/src/auth/dto/refresh-token.dto.ts
export class RefreshTokenDto {
    refreshToken: string;
}